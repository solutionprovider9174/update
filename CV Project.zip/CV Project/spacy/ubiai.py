import requests
import json


url ="https://api.ubiai.tools:8443/api_v1/train_model"
my_token = "/1d6fa01a-b3bc-11ec-939d-0242ac110002/no"

data = {
    "drop": 0.35,
    "max_batch": 25,
    "nb_iter": "500",
    "project": "6014",
    "selected_model": "blank",
    "selected_validation": "20",
    "model_type": "spacy",
    "with_annotate": False
}


response = requests.post(url+ my_token ,data=data)
print(response.status_code)
res = json.loads(response.content.decode("utf-8"))
print(res)
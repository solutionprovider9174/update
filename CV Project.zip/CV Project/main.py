import webbrowser
from io import StringIO
import nltk.data
from docx import Document
from spacy import displacy

from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser

import spacy
import re
import numpy
import numpy as np
import matplotlib.pyplot as plt
import mpld3

nlp = spacy.load('output/model-best/')
# nlp = spacy.load('model-2')
# nlp = spacy.load('spacy/model/')

skills = "dataset.jsonl"

ruler = nlp.add_pipe("entity_ruler", before="ner")
patterns = [
    {"label": "EMAIL", "pattern": [
        {"TEXT": {"REGEX": "([^@|\s]+@[^@]+\.[^@|\s]+)"}}]},
    {"label": "MOBILE", "pattern": [{"TEXT": {
        "REGEX": "\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4}"}}]},
]
ruler.add_patterns(patterns)

name = []
company = []
skill = []


def pdf(pdf_file):
    output_string = StringIO()
    with open(pdf_file, 'rb') as in_file:
        parser = PDFParser(in_file)
        doc = PDFDocument(parser)
        rsrcmgr = PDFResourceManager()
        device = TextConverter(rsrcmgr, output_string, laparams=LAParams())
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        for page in PDFPage.create_pages(doc):
            interpreter.process_page(page)

    x = output_string.getvalue()
    x = x.encode('ascii', 'ignore').decode()

    x = re.sub(' +', ' ', x)
    x = x.strip()
    x = re.sub(' +', ' ', str(x))

    x = x.replace(".", ".\n\n")

    new = nltk.data.load('tokenizers/punkt/english.pickle')
    x = '\n-----\n'.join(new.tokenize(x.strip(), realign_boundaries=True))

    x = x.replace(',,', ',')

    doc = nlp(x)

    print(nlp.pipe_names)

    for ent in doc.ents:
        print("{} ({}-{}, {})".format(ent.text,
              ent.start_char, ent.end_char, ent.label_))


pass


def docx(file):
    global skill

    positions = []
    def getText(filename):
        doc = Document(filename)
        fullText = []
        for para in doc.paragraphs:
            fullText.append(para.text)
        return '\n'.join(fullText)
    pass

    x = getText(file)
    x = x.encode('ascii', 'ignore').decode()
    doc = nlp(x)

    print(nlp.pipe_names)

    for ent in doc.ents:
        print("{} ({}-{}, {})".format(ent.text,
              ent.start_char, ent.end_char, ent.label_))
        if ent.label_ == "SKILL":
            skill.append(ent.text)
            print("{} ({}-{}, {})".format(ent.text,
                  ent.start_char, ent.end_char, ent.label_))
    return doc
pass


def showBrowser(doc):
    file = open("./html/cv_ent.html", "w")
    file.write(displacy.render(doc, style="ent", options=options))
    file.close()

    temp_html = open('./html/temp_graph.html', 'r')
    graph_ = temp_html.read()

    temp_cv = open('./html/cv_ent.html', 'r')
    cv_ = temp_cv.read()
    temp_cv.close()

    HTML = """
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>A Basic HTML5 Template</title>
        <meta name="description" content="A simple HTML5 Template for new projects.">
        <meta name="author" content="SitePoint">

        <meta property="og:title" content="A Basic HTML5 Template">
        <meta property="og:type" content="website">
        <meta property="og:url" content="https://www.sitepoint.com/a-basic-html5-template/">
        <meta property="og:description" content="A simple HTML5 Template for new projects.">
        <meta property="og:image" content="image.png">

        <link rel="icon" href="/favicon.ico">
        <link rel="icon" href="/favicon.svg" type="image/svg+xml">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png">

        <link rel="stylesheet" href="style.css">
    </head>

    <body>
    {}
    {}
    <script src="js/scripts.js"></script>
    </body>
    </html>
    """.format(graph_, cv_)

    cv_ent = open('./html/cv_ent.html', 'w')
    cv_ent.write('''<img src="my_plot.png" alt="Italian Trulli">''' + '\n'+cv_)
    cv_ent.close()

    cv_ent = open('./html/cv_ent.html', 'w')
    cv_ent.write(HTML)
    cv_ent.close()

    webbrowser.open('file:///C:/Users/P_D_G/Desktop/trainer/html/cv_ent.html')


pass


def showDisplacy(doc, options):
    displacy.serve(doc, style="ent", options=options,
                   port=8654, host="127.0.0.1")


pass


def chart():
    fig = plt.figure(figsize=(10, 5))
    keys_ = skillData.keys()
    keys = list(keys_)[:10]

    values_ = skillData.values()
    values = list(values_)[:10]
    print(values)

    plt.barh(keys, values)
    plt.savefig('./html/my_plot.png')
    plt.show()

    displacy.serve(doc, style="ent", options=options,
                   port=8654, host="127.0.0.1")


pass

doc = docx("./cv/cv4.docx")

fdist = dict(zip(*numpy.unique(skill, return_counts=True)))
skillData = {k: v for k, v in sorted(
    fdist.items(), key=lambda item: item[1], reverse=True)}

colors = {"JOBTITLE": "linear-gradient(90deg, #5353ff, #00d4ff)",  "COMPANY": "linear-gradient(90deg, #22c1c3, #fdbb2d)",
          "DATE": "linear-gradient(90deg, #3f5efb, #46fc4f)", "SKILL": "linear-gradient(90deg, #40fec2, #e078ff)",
          "CHARACTERISTIC": "linear-gradient(90deg, #40eafe, #ff7878)", "EMAIL": "linear-gradient(90deg, #aa9cfc, #fc9ce7)",
          "NAME": "linear-gradient(90deg, #aa9cfc, #fc9ce7)", "CERTIFICATE": "linear-gradient(90deg, #aa9cfc, #fc9ce7)",
          "EDUCATION": "linear-gradient(90deg, #aa9cfc, #fc9ce7)", "LANGUAGES": "linear-gradient(90deg, #aa9cfc, #fc9ce7)",
          "LOCATION": "linear-gradient(90deg, #aa9cfc, #fc9ce7)", "INDUSTRY": "linear-gradient(90deg, #aa9cfc, #fc9ce7)",
          "TIME": "linear-gradient(90deg, #aa9cfc, #fc9ce7)", "NUMBER": "linear-gradient(90deg, #aa9cfc, #fc9ce7)",
          "URL": "linear-gradient(90deg, #aa9cfc, #fc9ce7)"}
options = {"ents": ["JOBTITLE", "COMPANY", "DATE", "SKILL", "CHARACTERISTIC", "EMAIL", "NAME", "CERTIFICATE", "EDUCATION", "LANGUAGES", "LOCATION"
                    "INDUSTRY", "TIME", "NUMBER", "URL"], "colors": colors}

showDisplacy(doc, options)

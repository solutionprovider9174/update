const { db } = require("../../config/db_config");
const async_wrapper = require("../../service/async_wrapper");
const util = require("util");
const CustomErrorCreator = require("../../service/custome_error_creator");

const get_crime_List = async_wrapper(async (req, res, next) => {
  if (!req.query)
    return next(
      CustomErrorCreator.createCustomeError("fields are missing", 400)
    );

  const { toDate, fromDate, district } = req.query;

  if (!toDate || !fromDate)
    return next(
      CustomErrorCreator.createCustomeError("all fields are required", 400)
    );

  let query_val = " ";
  let query_data = [toDate, fromDate];
  let list_perm = [];

  if (district) {
    query_val += "and DISTRICT = ? ";
    query_data.push(district);
  }

  const query = util.promisify(db.query).bind(db);

  const getList = await query(
    `SELECT date(OCCURRED_ON_DATE) date, sum(ID) total_crimes from crime_details WHERE OCCURRED_ON_DATE between ? and ? ${query_val}  group by OCCURRED_ON_DATE `,
    query_data
  );

  for (let key in getList) {
   
    list_perm  = [];
    list_perm.push(getList[key].date.toISOString().split('T')[0]);

     
    let tempDate = getList[key].date;
    const date_val =  tempDate.setDate(
        tempDate.getDate() - 7
    );
   
    var previousDate = new Date(date_val);

    list_perm.push(previousDate.toISOString().split('T')[0]);

    if (district) {
      list_perm.push(district);
    }


    let getRes = await query(
      `SELECT sum(ID) total_crimes FROM crime_details WHERE OCCURRED_ON_DATE   > date (?) and OCCURRED_ON_DATE <=  date(?) ${query_val} `,
      list_perm
    );


    getList[key].moviengAvg = (getRes[0].total_crimes ?? 0) / 7;
  }

  return res.status(200).json({ s: 1, m: "success", r: getList });
});

module.exports = {
  get_crime_List,
};

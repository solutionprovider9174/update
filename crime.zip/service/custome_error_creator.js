

class CustomErrorCreator extends Error {

    constructor(message, statusCode) {
        super(message);
        this.message = message;
        this.statusCode = statusCode;
    }


    static createCustomeError(msg, statusCode = 400) {
        return new CustomErrorCreator(msg, statusCode);
    }

}


module.exports = CustomErrorCreator;
const express = require("express");
const { PORT } = require("./config/env_config");
const { pageNotFound } = require("./config/page_not_found");
const error_handler = require("./service/error_middleware");

// api route
const crimeRouter = require("./router/crime/crime_router");

// initialization
const server = express();

// sub router
const router = express.Router();
router.use("/crime",crimeRouter);

//middelware
server.use("/api/v1", router);
server.use(express.static("./public"));
server.use(express.json());
server.use(express.urlencoded({ extended: true }));

// error handler middelware
server.use(error_handler);


// not found api
server.use(pageNotFound);

// server listen
server.listen(PORT, () => console.log(`run server at - ${PORT}`));
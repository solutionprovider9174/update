require("dotenv").config();

module.exports =  {
    PORT,
    HOST,
    DB_PORT,
    DB_USER,
    DB_PASSWORD,
    DB_NAME
} = process.env;
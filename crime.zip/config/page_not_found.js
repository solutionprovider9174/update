module.exports.pageNotFound = (req, res, next)=>{
    return res.status(404).json({
        "s": 0,
        "m": "Page not found"
    });
    
}
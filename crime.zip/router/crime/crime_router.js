const router = require("express").Router();
const {
    get_crime_List
} = require("../../controller/crime/crime");


router.route("/getList").get( get_crime_List);


module.exports = router;